package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Text;

import java.util.ArrayList;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Group;
import pt.ubi.di.agrupameadmin.model.User;

public class ListGroupsActivity extends AppCompatActivity {

    private String eventId;
    private FirebaseFirestore db;

    private ArrayList<Group> groupsList = new ArrayList<Group>();
    private ArrayList<User> membersList = new ArrayList<User>();

    private LinearLayout groupsLinearLayout;
    private LinearLayout groupCardLinearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_groups);
    }

    @Override
    protected void onResume() {
        super.onResume();
        db = FirebaseFirestore.getInstance();
        Intent intent = getIntent();
        eventId = intent.getStringExtra("eventID");

        groupsLinearLayout = findViewById(R.id.list_groups_ll);

        getEventGroups();
    }

    private void getEventGroups() {
        db.collection("groups")
                .whereEqualTo("eventId", eventId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                Group group = doc.toObject(Group.class);
                                groupsList.add(group);
                            }
                            getGroupsMembers();
                        }
                    }
                });
    }

    private void getGroupsMembers() {
        db.collection("students")
                .whereNotEqualTo("groupId", "N/A")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                User member = doc.toObject(User.class);
                                membersList.add(member);
                            }
                            fillCards();
                        }
                    }

                });
    }

    private void fillCards() {
        for (Group group : groupsList) {
            ArrayList<User> groupMembers = new ArrayList<User>();

            groupCardLinearLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.card_group, null);
            TextView groupTitle = groupCardLinearLayout.findViewById(R.id.card_group_name);
            groupTitle.setText(group.getName());

            for (User member : membersList) {
                if (group.getUuid().equals(member.getGroupId())) {
                    if (member.isMentor()) {
                        TextView mentor = groupCardLinearLayout.findViewById(R.id.card_group_mentor);
                        mentor.setText("Mentor: " + member.getFirstName() + " " + member.getLastName());
                    } else {
                        LinearLayout cardGroupMember = (LinearLayout) getLayoutInflater().inflate(R.layout.card_group_member_tv, null);
                        TextView memberName = cardGroupMember.findViewById(R.id.card_member_name);
                        memberName.setText(member.getFirstName() + " " + member.getLastName());
                        groupCardLinearLayout.addView(cardGroupMember);
                    }
                }
            }
            groupsLinearLayout.addView(groupCardLinearLayout);
        }
    }
}