package pt.ubi.di.agrupameadmin.model;


import android.util.Log;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
    public static boolean isValidAdmin(String email, String password) {
        return !(email == null || email.isEmpty() || password == null || password.isEmpty() || password.length() < 6);
    }

    public static boolean isValidEvent(String name, String description, String startDate, String time,
                                       String endDate, int maxParticipants) {

        boolean validName = !(name.isEmpty() || name.length() <= 3);
        boolean validDescription = !(description.isEmpty() || description.length() > 400);
        boolean validStartDate = Validator.isValidDate(startDate);
        boolean validTime = Validator.isValidTime(time);
        boolean validEndDate = Validator.isValidDate((endDate));
        boolean validMaxParticipants = maxParticipants > 10;
        boolean isRealDates = realDates(startDate, endDate);

        return validName && validDescription && validStartDate && validTime && validEndDate && validMaxParticipants && isRealDates;
    }

    public static Date formatedStringToDate(String dateString) {
        SimpleDateFormat formatedDate = new SimpleDateFormat("dd/MM/yyyy");
        formatedDate.setLenient(false);
        Date javaDate;
        try {
            javaDate = formatedDate.parse(dateString);

        } catch (Exception e) {
            Log.e("VALIDATOR", e.getMessage());
            return null;
        }

        return javaDate;
    }

    private static boolean realDates(String startDate, String endDate) {
        SimpleDateFormat formatedDate = new SimpleDateFormat("dd/MM/yyyy");
        formatedDate.setLenient(false);

        try {
            Date javaStartDate = formatedDate.parse(startDate);
            Date javaEndDate = formatedDate.parse(endDate);

            if (javaEndDate.before(javaStartDate)) {
                return false;
            }
        } catch (Exception e) {
            Log.e("VALIDATOR", e.getMessage());
            return false;
        }

        return true;
    }

    public static boolean isValidDate(String date) {
        SimpleDateFormat formatedDate = new SimpleDateFormat("dd/MM/yyyy");
        formatedDate.setLenient(false);

        try {
            Date javaDate = formatedDate.parse(date);
        } catch (Exception e) {
            Log.e("VALIDATOR", e.getMessage());
            return false;
        }

        return true;
    }

    public static boolean isValidTime(String time) {

        String regex = "([01]?[0-9]|2[0-3]):[0-5][0-9]";
        Pattern p = Pattern.compile(regex);

        if (time == null) {
            return false;
        }
        Matcher m = p.matcher(time);

        return m.matches();
    }

    public static boolean isUserValid(String eventId, String firstName, String lastName,
                                      int age, String field, String residence, String email) {

        boolean validId =  eventId != null && eventId.length() == 8;
        boolean validNames = (firstName != null && lastName != null) && (firstName.length() >= 3 && lastName.length() >= 3);
        boolean validAge = age >= 10 && age <= 80;
        boolean validField = (field != null ) && field.length() >= 3;
        boolean validResidence = (residence != null) && residence.length() >= 3;
        boolean validEmail = (email != null) && email.length() >= 10;

        return validId && validNames && validAge && validField && validResidence && validEmail;
    }

}
