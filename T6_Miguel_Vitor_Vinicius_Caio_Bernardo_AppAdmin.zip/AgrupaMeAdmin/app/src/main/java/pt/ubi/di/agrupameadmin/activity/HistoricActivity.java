package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.List;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Admin;
import pt.ubi.di.agrupameadmin.model.Event;
import pt.ubi.di.agrupameadmin.model.Group;
import pt.ubi.di.agrupameadmin.model.User;

public class HistoricActivity extends AppCompatActivity {

    //Declarations -----------------------------------------------------//
    private String list;
    private Date today;
    private Intent intent;
    private Event event;
    private LinearLayout ll_father;
    private LinearLayout ll_child;
    private TextView tv_child_name;
    private TextView tv_child_date;
    private TextView title;
    private TextView description;
    private String now;
    private String end;
    private FirebaseFirestore db;
    //------------------------------------------------------------------//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historic);
    }

    //Fill with the contents --------------------------------------------------------------------------------------//

    public void fillHistoricContentEventNow() {

        description.setText(now);
        title.setText(list);

        db.collection("/events")
                .addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {

                            event = doc.toObject(Event.class);
                            if (event.getEndDate().after(today)) {
                                ll_child = (LinearLayout) getLayoutInflater().inflate(R.layout.event_buttons_ll, null);

                                tv_child_name = ll_child.findViewById(R.id.name_ll);
                                tv_child_date = ll_child.findViewById(R.id.date_ll);
                                //  Tag -------
                                Log.i("ID: ", event.getUuid());
                                ll_child.setTag(event.getUuid());
                                String[] dates = event.getEndDate().toString().split(" ");
                                tv_child_name.setText(event.getName());
                                tv_child_date.setText(dates[2] + " " + dates[1] + " " + dates[5]);
                                ll_father.addView(ll_child);
                            }
                        }

                    }
                });
    }

    public void fillHistoricContentEventEnd() {

        description.setText(end);
        title.setText(list);

        db.collection("events")
                .addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            event = doc.toObject(Event.class);
                            if (event.getEndDate().before(today)) {
                                ll_child = (LinearLayout) getLayoutInflater().inflate(R.layout.event_buttons_ll, null);
                                tv_child_name = ll_child.findViewById(R.id.name_ll);
                                tv_child_date = ll_child.findViewById(R.id.date_ll);
                                // Tag -------------------- //
                                ll_child.setTag(event.getUuid());
                                String[] dates = event.getEndDate().toString().split(" ");
                                tv_child_date.setText(dates[2] + " " + dates[1] + " " + dates[5]);
                                tv_child_name.setText(event.getName());
                                ll_father.addView(ll_child);
                            }
                        }
                    }
                });
    }

    private void fillHistoricContentAdmins() {
        title.setText(list);
        description.setText("Lista de todos os admins registrados nesta aplicação até o momento.");

        db.collection("/admins")
                .addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            Admin admin = doc.toObject(Admin.class);

                            ll_child = (LinearLayout) getLayoutInflater().inflate(R.layout.event_buttons_ll, null);
                            ll_child.setOnClickListener(null);
                            tv_child_name = ll_child.findViewById(R.id.name_ll);
                            tv_child_date = ll_child.findViewById(R.id.date_ll);
                            // Tag -------------------- //
                            ll_child.setTag(admin.getUid());
                            tv_child_date.setText(admin.getName());
                            tv_child_name.setText(admin.getEmail());
                            ll_father.addView(ll_child);

                        }
                    }
                });

    }

    private void fillHistoricContentUsers() {
        description.setText(end);
        title.setText(list);

        db.collection("students")
                .addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        Log.i("| -------- Users", "entrou");
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            User user = doc.toObject(User.class);
                            Log.i("| -------- Users", "" + user.getFirstName());
                            // Get LinearLayout -------------------------------------------- //
                            ll_child = (LinearLayout) getLayoutInflater().inflate(R.layout.card_participant_v, null);
                            TextView tv_child_name = ll_child.findViewById(R.id.card_participants_name_v);
                            TextView tv_child_email = ll_child.findViewById(R.id.card_participants_email_v);
                            ImageView tv_child_image = ll_child.findViewById(R.id.card_participants_img_v);
                            final TextView tv_child_groups = ll_child.findViewById(R.id.card_participants_group_v);
                            // -------------------------------------------------------- //
                            // Set dates LinearLayout --------------------------------- //
                            ll_child.setTag(user.getID());
                            tv_child_email.setText(user.getEmail());
                            tv_child_name.setText(user.getFirstName());
                            if (user.getUrl() == null) {
                                Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/agrupameignite.appspot.com/o/images%2Favatar.jpg?alt=media&token=2d945f45-68c9-4b66-92f9-f8a9f8824448")
                                        .into(tv_child_image);
                            } else {
                                Picasso.get().load(user.getUrl()).into(tv_child_image);
                            }
                            if (!user.getGroupId().equals("N/A")) {
                                db.collection("groups")
                                        .whereEqualTo("uuid", user.getGroupId())
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    for (QueryDocumentSnapshot doc : task.getResult()) {
                                                        Group group = doc.toObject(Group.class);
                                                        tv_child_groups.setText(group.getName());
                                                    }
                                                }
                                            }
                                        });
                            }
                            ll_father.addView(ll_child);
                            // -------------------------------------------------------- //

                        }
                    }
                });
    }
    //------------------------------------------------------------------------------------------------------------------------- //

    //Navigation ----------------------------//
    public void goBack(View view) {
        finish();
    }
    //---------------------------------------//

    //Ons--------------------------------------------------------------//

    @Override
    protected void onResume() {
        super.onResume();

        //Initialise variables----------------------//
        today = new Date(System.currentTimeMillis());
        intent = getIntent();
        list = intent.getStringExtra("list");
        ll_father = findViewById(R.id.historic_linearlayout);
        description = findViewById(R.id.list_content_description);
        title = findViewById(R.id.list_content_title);
        now = "Lista de todos os eventos que ainda estão ocorrendo!";
        end = "Lista de todos os eventos que já ocorreram!";
        db = FirebaseFirestore.getInstance();
        //------------------------------------------//

        ll_father.removeAllViews();

        switch (list) {
            case "0":
                list = "Eventos Encerrados!";
                fillHistoricContentEventEnd();
                break;
            case "1":
                list = "Eventos a Decorrer!";
                fillHistoricContentEventNow();
                break;
            case "2":
                Log.i("Switch", "entro");
                list = "Lista de Usuarios";
                fillHistoricContentUsers();
                break;
            case "3":
                list = "Lista de Administradores";
                fillHistoricContentAdmins();
                break;
        }
    }

    public void goToEventInformation(View view) {
        Intent intent = new Intent(this, ShowEventsActivity.class);
        intent.putExtra("Id_Event", "" + view.getTag());
        intent.putExtra("Event", list);
        startActivity(intent);
    }
    //-------------------------------------------------------------------//

}