package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.fragment.ShowEventsEditFragment;
import pt.ubi.di.agrupameadmin.fragment.ShowEventsParticipantsFragments;
import pt.ubi.di.agrupameadmin.model.Event;
import pt.ubi.di.agrupameadmin.model.NavigationHost;
import pt.ubi.di.agrupameadmin.model.Validator;

public class ShowEventsActivity extends AppCompatActivity {

    // ---------------------------------------------------- //
    // Declarations of the variables ---------------------- //
    private String id;
    private Intent intent;
    private String eventCategory;
    private TextView TvTitle;
    private TextView TvDescription;
    private EditText et_name;
    private EditText et_desc;
    private EditText et_date_et;
    private EditText et_date_end_et;
    private EditText et_time_et;
    private EditText et_max;
    private EditText et_mentor_code;
    private EditText et_user_code;
    private TextView tv_name;
    private TextView tv_desc;
    private TextView tv_date_et;
    private TextView tv_date_end_et;
    private TextView tv_time_et;
    private TextView tv_max;
    private TextView tv_mentor_code;
    private TextView tv_user_code;
    private LinearLayout ll_father;
    private FirebaseFirestore db;
    // Test --------- //
    private QueryDocumentSnapshot users;
    private QueryDocumentSnapshot event;
    // ---------------------------------------------------- //


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_events);

    }

    @Override
    protected void onResume() {

        super.onResume();
        // ---------------------------------------------------- //
        // Get Intents ---------------------------------------- //
        intent = getIntent();
        id = intent.getStringExtra("Id_Event");
        eventCategory = intent.getStringExtra("Event");
        // ---------------------------------------------------- //

        // ---------------------------------------------------- //
        // Set Title and description -------------------------- //
        TvTitle = findViewById(R.id.show_event_title);
        TvDescription = findViewById(R.id.show_event_description);
        ll_father = findViewById(R.id.show_event_description_sv_ll);
        db = FirebaseFirestore.getInstance().getInstance();
        // ---------------------------------------------------- //

        // ---------------------------------------------------- //
        // Switch the event category (finished or continue) --- //
        switch (eventCategory) {
            case "Eventos Encerrados!":
                TvDescription.setText("Informações do evento que ja ocorreu, não se pode alterar as infomações! ");
                Button btt = findViewById(R.id.show_event_button_edit);
                btt.setText("Voltar");
                TvTitle.setText(eventCategory);
                showEventInformationEnd();
                break;
            case "Eventos a Decorrer!":
                TvDescription.setText("Informações do evento que está ocorrendo!");
                TvTitle.setText(eventCategory);
                showEventInformationNow();
                break;
        }
        // ---------------------------------------------------- //
    }

    public void showEventInformationNow() {
        db.collection("events").addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    return;
                }
                List<DocumentSnapshot> docs = value.getDocuments();
                for (DocumentSnapshot doc : docs) {
                    Event event = doc.toObject(Event.class);
                    Log.i("Event", "-> " + event.getUuid().toString());
                    if (event.getUuid().equals(id)) {
                        LinearLayout ll_child = (LinearLayout) getLayoutInflater().inflate(R.layout.show_event_fragment_not_edit, null);

                        // ---------------------------------------------------- //
                        // Get EditText from XML ------------------------------ //
                        tv_name = ll_child.findViewById(R.id.show_event_name);
                        tv_desc = ll_child.findViewById(R.id.show_event_desc);
                        tv_date_et = ll_child.findViewById(R.id.show_event_date_et);
                        tv_date_end_et = ll_child.findViewById(R.id.show_event_end_et);
                        tv_time_et = ll_child.findViewById(R.id.show_event_time_et);
                        tv_max = ll_child.findViewById(R.id.show_event_max_participants_et);
                        tv_mentor_code = ll_child.findViewById(R.id.show_event_mentor_code);
                        tv_user_code = ll_child.findViewById(R.id.show_event_user_code);
                        // ---------------------------------------------------- //

                        // ---------------------------------------------------- //
                        // Fill TextView from XML ----------------------------- //
                        tv_name.setText(event.getName());
                        tv_desc.setText(event.getDescription().toString());
                        tv_date_et.setText(event.getStartDate().toString());
                        tv_date_end_et.setText(event.getEndDate().toString());
                        tv_time_et.setText(event.getTime());
                        tv_max.setText("" + event.getMaxParticipants());
                        tv_mentor_code.setText(event.getMentorCode());
                        tv_user_code.setText(event.getUserCode());
                        ll_father.addView(ll_child);
                        // ---------------------------------------------------- //
                        break;
                    }
                }

            }
        });
    }

    public void showEventInformationEnd() {
        db.collection("events")
                .addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            Event event = doc.toObject(Event.class);
                            Log.i("Event", "-> " + event.getUuid().toString());
                            if (event.getUuid().equals(id)) {
                                LinearLayout ll_child = (LinearLayout) getLayoutInflater().inflate(R.layout.show_event_fragment_not_edit, null);

                                // ---------------------------------------------------- //
                                // Get EditText from XML ------------------------------ //
                                tv_name = ll_child.findViewById(R.id.show_event_name);
                                tv_desc = ll_child.findViewById(R.id.show_event_desc);
                                tv_date_et = ll_child.findViewById(R.id.show_event_date_et);
                                tv_date_end_et = ll_child.findViewById(R.id.show_event_end_et);
                                tv_time_et = ll_child.findViewById(R.id.show_event_time_et);
                                tv_max = ll_child.findViewById(R.id.show_event_max_participants_et);
                                tv_mentor_code = ll_child.findViewById(R.id.show_event_mentor_code);
                                tv_user_code = ll_child.findViewById(R.id.show_event_user_code);
                                // ---------------------------------------------------- //

                                // ---------------------------------------------------- //
                                // Fill TextView from XML ----------------------------- //
                                tv_name.setText(event.getName());
                                tv_desc.setText(event.getDescription().toString());
                                tv_date_et.setText(event.getStartDate().toString());
                                tv_date_end_et.setText(event.getEndDate().toString());
                                tv_time_et.setText(event.getTime());
                                tv_max.setText("" + event.getMaxParticipants());
                                tv_mentor_code.setText(event.getMentorCode());
                                tv_user_code.setText(event.getUserCode());
                                ll_father.addView(ll_child);
                                // ---------------------------------------------------- //
                                break;
                            }
                        }
                    }
                });
    }

    public void showEventEditOrBack(View view) {

            finish();
    }


    // Function get user in event --------------------------------------------------------------- //
    public void ge5tEvent() {
        db.collection("events")
                .whereEqualTo("uuid", id)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.i("Hello", " => " + document.getData());
                                Event aux = document.toObject(Event.class);
                                event = document;

                            }
                            getUsers();
                        } else {
                            Log.i("Hello", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    public void getUsers() {
        db.collection("students")
                .whereIn("code", Arrays.asList(event.get("mentorCode"), event.get("userCode")))
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.i("Hello", " => " + document.getData());

                            }
                        } else {
                            Log.i("Hello", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }
    // ------------------------------------------------------------------------------------------ //

}