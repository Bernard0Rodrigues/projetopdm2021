package pt.ubi.di.agrupameadmin.model;

import java.util.UUID;

public class Group {
    private String uuid;
    private String name;
    private String eventId;

    public Group() {

    }

    public Group(String uuid, String name, String eventId) {
        this.uuid = uuid;
        this.name = name;
        this.eventId = eventId;
    }

    public Group(String name, String eventId) {
        this.name = name;
        this.eventId = eventId;
        this.uuid = UUID.randomUUID().toString();
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
