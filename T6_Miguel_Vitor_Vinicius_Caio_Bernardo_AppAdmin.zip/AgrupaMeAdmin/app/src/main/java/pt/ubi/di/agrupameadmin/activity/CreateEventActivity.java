package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Event;
import pt.ubi.di.agrupameadmin.model.Validator;

public class CreateEventActivity extends AppCompatActivity {

    EditText nameEditText;
    EditText descriptionEditText;
    EditText startDateEditText;
    EditText timeEditText;
    EditText endDateEditText;
    EditText maxParticipantsEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        // EditText initialization ------------------------------------------------------------ //
        nameEditText = findViewById(R.id.create_event_name_et);
        descriptionEditText = findViewById(R.id.create_event_desc_et);
        startDateEditText = findViewById(R.id.create_event_date_et);
        timeEditText = findViewById(R.id.create_event_time_et);
        endDateEditText = findViewById(R.id.create_event_date_end_et);
        maxParticipantsEditText = findViewById(R.id.create_event_max_participants_et);
        // ----------------------------------------------------------------------------------- //
    }

    public void createEvent(View view) {
        String name = nameEditText.getText().toString();
        String description = descriptionEditText.getText().toString();
        String startDate = startDateEditText.getText().toString();
        String time = timeEditText.getText().toString();
        String endDate = endDateEditText.getText().toString();
        int maxParticipants = Integer.parseInt(maxParticipantsEditText.getText().toString());

        boolean isValidInput = Validator.isValidEvent(name, description, startDate, time, endDate, maxParticipants);

        if (!isValidInput) {
            Toast.makeText(this, "Dados inválidos, verifique novamente", Toast.LENGTH_LONG).show();
            return;
        }


        final Event event = new Event(name, description, Validator.formatedStringToDate(startDate), time,
                Validator.formatedStringToDate(endDate), maxParticipants);

        FirebaseFirestore.getInstance().collection("events")
                .add(event)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(CreateEventActivity.this, "Evento criado com sucesso!", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(CreateEventActivity.this, "Informações inválidas!", Toast.LENGTH_SHORT).show();
                    }
                });

    }
}