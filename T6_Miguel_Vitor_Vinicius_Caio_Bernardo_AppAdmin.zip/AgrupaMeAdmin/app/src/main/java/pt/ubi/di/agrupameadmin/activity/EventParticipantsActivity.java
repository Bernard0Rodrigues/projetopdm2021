package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.Arrays;
import java.util.List;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Event;
import pt.ubi.di.agrupameadmin.model.Group;
import pt.ubi.di.agrupameadmin.model.User;

public class EventParticipantsActivity extends AppCompatActivity {

    private String eventId;
    private String mentorCode;
    private String userCode;

    private LinearLayout participantCardLinearLayout;
    private LinearLayout participantsLinearLayout;


    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_participants);

        db = FirebaseFirestore.getInstance();
        Intent intent = getIntent();
        eventId = intent.getStringExtra("eventID");

        participantsLinearLayout = findViewById(R.id.event_participants_ll);
        loadParticipants();
    }

    public void loadParticipants() {
        db.collection("events")
                .whereEqualTo("uuid", eventId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                Event event = doc.toObject(Event.class);

                                db.collection("students")
                                        .whereIn("code", Arrays.asList(event.getUserCode(), event.getMentorCode()))
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    for (QueryDocumentSnapshot doc : task.getResult()) {
                                                        User user = doc.toObject(User.class);
                                                        participantCardLinearLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.card_participant_v, null);
                                                        ImageView imgIv = participantCardLinearLayout.findViewById(R.id.card_participants_img_v);
                                                        TextView nameTv = participantCardLinearLayout.findViewById(R.id.card_participants_name_v);
                                                        TextView emailTv = participantCardLinearLayout.findViewById(R.id.card_participants_email_v);
                                                        final TextView groupTv = participantCardLinearLayout.findViewById(R.id.card_participants_group_v);

                                                        nameTv.setText(user.getFirstName() + " " + user.getLastName());
                                                        emailTv.setText(user.getEmail());

                                                        if (user.getUrl() == null) {
                                                            Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/agrupameignite.appspot.com/o/images%2Favatar.jpg?alt=media&token=2d945f45-68c9-4b66-92f9-f8a9f8824448")
                                                                    .into(imgIv);
                                                        } else {
                                                            Picasso.get().load(user.getUrl()).into(imgIv);
                                                        }

                                                        if (!user.getGroupId().equals("N/A")) {
                                                            db.collection("groups")
                                                                    .whereEqualTo("uuid", user.getGroupId())
                                                                    .get()
                                                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                            if (task.isSuccessful()) {
                                                                                for (QueryDocumentSnapshot doc : task.getResult()) {
                                                                                    Group group = doc.toObject(Group.class);
                                                                                    groupTv.setText(group.getName());
                                                                                }
                                                                            }
                                                                        }
                                                                    });
                                                        }
                                                        participantsLinearLayout.addView(participantCardLinearLayout);

                                                    }
                                                } else {
                                                    Toast.makeText(EventParticipantsActivity.this, "Nenhum participante registrado!", Toast.LENGTH_SHORT).show();
                                                }

                                            }
                                        });
                            }
                        }
                    }
                });


    }
}