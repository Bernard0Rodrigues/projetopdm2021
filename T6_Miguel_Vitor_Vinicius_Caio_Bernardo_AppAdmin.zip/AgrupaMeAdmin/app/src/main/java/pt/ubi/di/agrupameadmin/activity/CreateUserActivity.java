package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Event;
import pt.ubi.di.agrupameadmin.model.School;
import pt.ubi.di.agrupameadmin.model.User;
import pt.ubi.di.agrupameadmin.model.Validator;

public class CreateUserActivity extends AppCompatActivity {

    private EditText eventIdEditText;
    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText ageEditText;
    private Spinner genderSpinner;
    private Spinner schoolSpinner;
    private EditText fieldEditText;
    private EditText residenceEditText;
    private EditText emailEditText;

    private String[] genders = {"Masculino", "Feminino"};
    private ArrayList<String> schools = new ArrayList<String>();

    private String eventId;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String school;
    private String field;
    private String residence;
    private String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        // Initialization -------------------------------------------------------------------- //
        eventIdEditText = findViewById(R.id.create_user_event_id_et);
        firstNameEditText = findViewById(R.id.create_user_first_name_et);
        lastNameEditText = findViewById(R.id.create_user_last_name_et);
        ageEditText = findViewById(R.id.create_user_age_et);
        genderSpinner = findViewById(R.id.create_user_gender_sp);
        schoolSpinner = findViewById(R.id.create_user_school_sp);
        fieldEditText = findViewById(R.id.create_user_field_study_et);
        residenceEditText = findViewById(R.id.create_user_residence_et);
        emailEditText = findViewById(R.id.create_user_email_et);
        //  ---------------------------------------------------------------------------------- //
        // Fetch schools available ----------------------------------------------------------- //
        FirebaseFirestore.getInstance().collection("schools")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            School school = doc.toObject(School.class);
                            schools.add(school.getName());
                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(CreateUserActivity.this, android.R.layout.simple_spinner_item, schools);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        schoolSpinner.setAdapter(adapter);
                        schoolSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                school = (String) parent.getItemAtPosition(position);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                                //TODO: onNothingSelected for spinner
                            }
                        });

                    }
                });

        // ----------------------------------------------------------------------------------- //
        // Gender Spinner -------------------------------------------------------------------- //
        ArrayAdapter<String> adapter_g = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, genders);
        adapter_g.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(adapter_g);
        genderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                gender = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //TODO: onNothingSelected for spinner
            }
        });
        // ------------------------------------------------------------------------------------- //

    }

    public void createUser(View view) {
        eventId = eventIdEditText.getText().toString();
        firstName = firstNameEditText.getText().toString();
        lastName = lastNameEditText.getText().toString();
        age = Integer.parseInt(ageEditText.getText().toString());
        field = fieldEditText.getText().toString();
        residence = residenceEditText.getText().toString();
        email = emailEditText.getText().toString();

        boolean isUserValid = Validator.isUserValid(eventId, firstName, lastName, age, field, residence, email);

        if (!isUserValid) {
            Toast.makeText(this, "Dados Inválidos", Toast.LENGTH_SHORT).show();
        } else {
            FirebaseFirestore.getInstance().collection("events")
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                            if (error != null) {
                                return;
                            }
                            List<DocumentSnapshot> docs = value.getDocuments();
                            for (DocumentSnapshot doc : docs) {
                                Event event = doc.toObject(Event.class);
                                if (event.getMentorCode().equals(eventId) || event.getUserCode().equals(eventId)) {
                                    User user;
                                    if (event.getMentorCode().equals(eventId)) {
                                        user = new User(email, firstName, lastName, school, field, residence, gender, age, true, eventId);
                                    } else {
                                        user = new User(email, firstName, lastName, school, field, residence, gender, age, false, eventId);
                                    }

                                    FirebaseFirestore.getInstance().collection("students")
                                            .add(user)
                                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                @Override
                                                public void onSuccess(DocumentReference documentReference) {
                                                    Toast.makeText(CreateUserActivity.this, "Aluno adicionado com sucesso!", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(CreateUserActivity.this, "Erro ao registrar aluno!", Toast.LENGTH_SHORT).show();
                                                }
                                            });

                                }
                            }
                        }
                    });
        }
    }

}