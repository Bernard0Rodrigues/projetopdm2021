package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Admin;
import pt.ubi.di.agrupameadmin.model.Validator;

public class CreateAdminActivity extends AppCompatActivity {

    private EditText nameEditText;
    private EditText emailEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_admin);

        nameEditText = findViewById(R.id.create_admin_name_et);
        emailEditText = findViewById(R.id.create_admin_email_et);
        passwordEditText = findViewById(R.id.create_admin_password_et);
    }

    public void createAdmin(View view) {
        final String name = nameEditText.getText().toString();
        final String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        boolean isValidAdmin = Validator.isValidAdmin(email, password) && !name.isEmpty();

        if (!isValidAdmin) {
            Toast.makeText(this, "Dados Inválidos!", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        String adminId = task.getResult().getUser().getUid();
                        Admin admin = new Admin(adminId, name, email);

                        FirebaseFirestore.getInstance().collection("admins")
                                .add(admin)
                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                    @Override
                                    public void onSuccess(DocumentReference documentReference) {
                                        Toast.makeText(CreateAdminActivity.this, "Admin criado com sucesso!", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(CreateAdminActivity.this, "Erro ao criar o Admin!", Toast.LENGTH_SHORT).show();
                                    }
                                });
                        Toast.makeText(CreateAdminActivity.this, "Admin criado com sucesso!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(CreateAdminActivity.this, "Não foi possível criar o admin!", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}