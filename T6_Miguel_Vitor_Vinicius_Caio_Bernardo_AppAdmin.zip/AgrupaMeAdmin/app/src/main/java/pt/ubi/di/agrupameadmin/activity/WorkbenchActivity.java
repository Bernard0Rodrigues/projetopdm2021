package pt.ubi.di.agrupameadmin.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;
import java.util.UUID;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.fragment.WorkbenchCreateFragment;
import pt.ubi.di.agrupameadmin.fragment.WorkbenchHomeFragment;
import pt.ubi.di.agrupameadmin.fragment.WorkbenchListFragment;
import pt.ubi.di.agrupameadmin.fragment.WorkbenchSettingFragment;
import pt.ubi.di.agrupameadmin.model.Admin;
import pt.ubi.di.agrupameadmin.model.NavigationHost;
import pt.ubi.di.agrupameadmin.model.School;
import pt.ubi.di.agrupameadmin.model.User;

public class WorkbenchActivity extends AppCompatActivity implements NavigationHost {

    // ------------------------------------- //
    // Variables --------------------------- //
    private FirebaseFirestore db;
    // ------------------------------------- //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workbench);
        verifyAuthentication();
    }

//  |--------------------------  Authentication  --------------------------|

    private void verifyAuthentication() {
        if (FirebaseAuth.getInstance().getUid() == null) {
            Intent invalidUserIntent = new Intent(this, MainActivity.class);

            invalidUserIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(invalidUserIntent);
        }
    }


//  |--------------------------  NavigationBar  --------------------------|

    @Override
    public void navigateTo(Fragment fragment, boolean addToBackstack) {
        FragmentTransaction transaction =
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.workbench_content_ll, fragment);
        transaction.commit();
    }

    public void launchCreateEventActivity(View view) {
        Intent createEventIntent = new Intent(this, CreateEventActivity.class);
        startActivity(createEventIntent);
    }

    public void launchCreateUserActivity(View view) {
        Intent createUserIntent = new Intent(this, CreateUserActivity.class);
        startActivity(createUserIntent);
    }

    public void launchCreateAdminActivity(View view) {
        Intent createAdminIntent = new Intent(this, CreateAdminActivity.class);
        startActivity(createAdminIntent);
    }

    public void logout(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        FirebaseAuth.getInstance().signOut();
        startActivity(intent);
        finish();
    }

    public void addSchoolDialog(View view) {
        final AlertDialog.Builder alert = new AlertDialog.Builder(WorkbenchActivity.this, R.style.AlertDialogTheme);
        final EditText schoolEditText = new EditText(this);
        schoolEditText.setHint("Nome da escola");
        schoolEditText.setTextColor(getResources().getColor(R.color.primaryWhite));
        schoolEditText.setHintTextColor(getResources().getColor(R.color.secondaryGray));
        alert.setTitle("Adicionar Escola");
        alert.setView(schoolEditText);

        alert.setPositiveButton("Adicionar", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog, int whichButton) {
                String schoolName = schoolEditText.getText().toString();
                String schoolId = UUID.randomUUID().toString();

                boolean isSchoolNameValid = !schoolName.isEmpty() && schoolName.length() >= 3;

                if (isSchoolNameValid) {
                    School school = new School(schoolId, schoolName);

                    FirebaseFirestore.getInstance().collection("schools")
                            .add(school)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Toast.makeText(WorkbenchActivity.this, "Escola adicionada com sucesso!", Toast.LENGTH_SHORT).show();
                                    dialog.cancel();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(WorkbenchActivity.this, "Não foi possível adicionar a escola", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(WorkbenchActivity.this, "Nome da escola inválido", Toast.LENGTH_SHORT).show();
                }

            }
        });

        alert.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                dialog.cancel();
            }
        });

        alert.show();
    }

    public void historicEventEnd(View view) {
        Intent intent = new Intent(this, HistoricActivity.class);
        intent.putExtra("list", "0");
        startActivity(intent);
    }

    public void historicEventNow(View view) {
        Intent intent = new Intent(this, HistoricActivity.class);
        intent.putExtra("list", "1");
        startActivity(intent);
    }

    public void historicUsers(View view) {
        Intent intent = new Intent(this, HistoricActivity.class);
        intent.putExtra("list", "2");
        Log.i("Historic", "entrou");
        startActivity(intent);
    }

    public void historicAdmins(View view) {
        Intent intent = new Intent(this, HistoricActivity.class);
        intent.putExtra("list", "3");
        startActivity(intent);
    }

//  |--------------------------  onClick Fragment  --------------------------| Change the content view of the workbenchActivity

    //TODO: refactor function
    public void settingFragment(View view) {
        ((NavigationHost) WorkbenchActivity.this).navigateTo(new WorkbenchSettingFragment(), false);

        db.collection("admins")
                .addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            Log.e("teste", error.getMessage(), error);
                            return;
                        }
                        String id = FirebaseAuth.getInstance().getUid();
                        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();

                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            Admin admin = doc.toObject(Admin.class);
                            if (id.equals(admin.getUid())) {
                                TextView tv1 = findViewById(R.id.settings_name);
                                TextView tv2 = findViewById(R.id.settings_email);
                                tv1.setText(admin.getName());
                                tv2.setText(email);
                                break;
                            }
                        }
                    }
                });
    }

    public void homeFragment(View view) {
        ((NavigationHost) WorkbenchActivity.this).navigateTo(new WorkbenchHomeFragment(), false);
    }

    public void listFragment(View view) {
        ((NavigationHost) WorkbenchActivity.this).navigateTo(new WorkbenchListFragment(), false);
    }

    public void createFragment(View view) {
        ((NavigationHost) WorkbenchActivity.this).navigateTo(new WorkbenchCreateFragment(), false);
    }

    public void launchGroupsActivity(View view) {
        Intent groupsIntent = new Intent(this, GroupsActivity.class);
        startActivity(groupsIntent);
    }

//  |--------------------------  ons  --------------------------|  Reset the content view of the workbenchActivity
/*
    @Override
    protected void onResume() {
        super.onResume();
        homeFragment(findViewById(R.id.workbench_content_ll_father));
        final String adminId = FirebaseAuth.getInstance().getUid();

        FirebaseFirestore.getInstance().collection("admins")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            Admin admin = doc.toObject(Admin.class);
                            if (admin.getUid().equals(adminId)) {
                                String name = admin.getName();
                                TextView adminIconTv = findViewById(R.id.workbench_admin_icon);
                                adminIconTv.setText(Character.toString(name.charAt(0)));
                            }
                        }
                    }
                });
    }*/

    @Override
    protected void onResume() {
        super.onResume();
        db = FirebaseFirestore.getInstance();
        homeFragment(findViewById(R.id.workbench_content_ll_father));
        db.collection("admins").whereEqualTo("uid", FirebaseAuth.getInstance().getUid())
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            return;
                        }
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            Admin admin = doc.toObject(Admin.class);
                            String name = admin.getName();
                            TextView adminIconTv = findViewById(R.id.workbench_admin_icon);
                            adminIconTv.setText(Character.toString(name.charAt(0)));
                        }
                    }
                });
    }

}