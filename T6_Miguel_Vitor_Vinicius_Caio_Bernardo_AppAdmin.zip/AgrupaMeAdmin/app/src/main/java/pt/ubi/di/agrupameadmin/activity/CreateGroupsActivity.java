package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Event;
import pt.ubi.di.agrupameadmin.model.Group;
import pt.ubi.di.agrupameadmin.model.User;

public class CreateGroupsActivity extends AppCompatActivity {

    private String eventId;
    private String userCode;
    private String mentorCode;
    private String eventName;
    private EditText man;
    private EditText woman;
    private TextView numberStudents;
    private int totalStudents;

    private FirebaseFirestore db;

    private ArrayList<User> mentorsList = new ArrayList<User>();
    private ArrayList<User> manList = new ArrayList<User>();
    private ArrayList<User> womanList = new ArrayList<User>();
    private ArrayList<User> aux = new ArrayList<User>();

    private int numOfGroupsOfEvent = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_groups);

    }

    @Override
    protected void onResume() {
        super.onResume();
        db = FirebaseFirestore.getInstance();
        Intent intent = getIntent();
        totalStudents = mentorsList.size() + womanList.size() + manList.size();
        eventId = intent.getStringExtra("eventID");
        mentorCode = intent.getStringExtra("mentorCode");
        userCode = intent.getStringExtra("userCode");
        eventName = intent.getStringExtra("eventName");
        numberStudents = findViewById(R.id.create_event_desc_number_of_students);
        getMentors();
        numberStudents.setText("Homens " + manList.size() + " mulheres " + womanList.size() + " mentores " + mentorsList.size());


    }

    public void createGroups(View view) {

        int groupsCount = 0;
        man = findViewById(R.id.numberOfMan);
        woman = findViewById(R.id.numberOfWoman);
        int numOfMan;
        int numOfWoman;
        try {
            numOfWoman = Integer.parseInt(woman.getText().toString());
            numOfMan = Integer.parseInt(man.getText().toString());
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Precisa preenche todos os campos com valores validos!", Toast.LENGTH_LONG).show();
            return;
        }


        int numOfPossibleGroups = mentorsList.size();
        if (numOfMan == 0 && numOfWoman == 0) {
            Toast.makeText(getApplicationContext(), "Pelo menos um dos campos não pode ser zero!", Toast.LENGTH_LONG).show();
            return;
        }
        aux.clear();
        for (int i = 0; i < numOfMan; i++) {
            if (manList.size() == 0) {
                Toast.makeText(getApplicationContext(), "Homens insuficientes para formar um grupo com essa configuração!", Toast.LENGTH_LONG).show();
                return;
            }
            User userMan = manList.remove(0);
            aux.add(userMan);
        }

        for (int i = 0; i < numOfWoman; i++) {
            if (womanList.size() == 0) {
                Toast.makeText(getApplicationContext(), "Mulheres insuficientes para formar um grupo com essa configuração!", Toast.LENGTH_LONG).show();
                return;
            }
            User userWoman = womanList.remove(0);
            aux.add(userWoman);
        }

        if (mentorsList.size() == 0) {
            Toast.makeText(getApplicationContext(), "Mentores insuficientes para formar um grupo com essa configuração!", Toast.LENGTH_LONG).show();
            return;
        }
        User userMentor = mentorsList.remove(0);
        aux.add(userMentor);

        groupsCount++;
        numOfPossibleGroups--;
        createGroup();
    }


    public void getMentors() {
        db.collection("students")
                .whereEqualTo("code", mentorCode).whereEqualTo("groupId", "N/A")

                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                User mentor = doc.toObject(User.class);
                                mentorsList.add(mentor);
                            }
                            getMan();
                        }
                    }
                });
    }

    public void getMan() {
        db.collection("students")
                .whereEqualTo("code", userCode).whereEqualTo("gender", "Masculino").whereEqualTo("groupId", "N/A")

                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                User userMan = doc.toObject(User.class);
                                manList.add(userMan);
                            }
                            getWoman();
                        }
                    }
                });
    }

    public void getWoman() {
        db.collection("students")
                .whereEqualTo("gender", "Feminino")
                .whereEqualTo("code", userCode)
                .whereEqualTo("groupId", "N/A")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.i("Hello", " => " + document.getData());
                                User user = document.toObject(User.class);
                                womanList.add(user);
                                numberStudents.setText("Homens " + manList.size() + " mulheres " + womanList.size() + " mentores " + mentorsList.size());
                            }
                        } else {
                            Log.i("Hello", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    public void createGroup() {
        final Group group = new Group(genGroupName(), eventId);
        for (User temo : aux) {
            Log.i("Aux", temo.getFirstName());
        }
        db.collection("groups")
                .add(group)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        for (User member : aux) {
                            db.collection("students")
                                    .whereEqualTo("id", member.getID())
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            if (task.isSuccessful()) {
                                                for (QueryDocumentSnapshot doc : task.getResult()) {
                                                    db.collection("students")
                                                            .document(doc.getId())
                                                            .update("groupId", group.getUuid());
                                                    numberStudents.setText("Homens " + manList.size() + " mulheres " + womanList.size() + " mentores " + mentorsList.size());
                                                    Toast.makeText(getApplicationContext(), "Grupo criado com sucesso! Sobraram " + totalStudents, Toast.LENGTH_LONG).show();
                                                }
                                            }
                                        }

                                    });
                        }
                    }
                });
    }

    private String genGroupName() {
        Event event = new Event();
        return eventName + "-" + event.genCode();
    }

}