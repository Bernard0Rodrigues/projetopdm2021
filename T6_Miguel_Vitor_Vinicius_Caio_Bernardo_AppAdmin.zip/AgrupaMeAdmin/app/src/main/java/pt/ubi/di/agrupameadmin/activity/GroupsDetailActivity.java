package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Event;

public class GroupsDetailActivity extends AppCompatActivity {

    private TextView titleTv;
    private TextView participantsTv;
    private TextView maxParticipantsTv;
    private TextView studentsTv;
    private TextView mentorsTv;

    private String eventId;
    private String mentorCode;
    private String userCode;
    private String eventName;
    private int students = 0;
    private int mentors = 0;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups_detail);

        db = FirebaseFirestore.getInstance();

        Intent intent = getIntent();
        eventId = intent.getStringExtra("eventID");

        titleTv = findViewById(R.id.groups_detail_title);
        participantsTv = findViewById(R.id.groups_detail_participants);
        studentsTv = findViewById(R.id.groups_detail_students);
        mentorsTv = findViewById(R.id.groups_detail_mentors);

        db.collection("events")
                .whereEqualTo("uuid", eventId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                Event event = doc.toObject(Event.class);
                                titleTv.setText(event.getName());
                                userCode = event.getUserCode();
                                eventName = event.getName();
                                mentorCode = event.getMentorCode();

                                db.collection("students")
                                        .whereEqualTo("code", mentorCode)
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    mentors = task.getResult().size();
                                                    mentorsTv.setText("Mentores: " + mentors);

                                                    db.collection("students")
                                                            .whereEqualTo("code", userCode)
                                                            .get()
                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                    if (task.isSuccessful()) {
                                                                        for (QueryDocumentSnapshot doc : task.getResult()) {
                                                                            students++;
                                                                        }
                                                                        studentsTv.setText("Estudantes: " + students);
                                                                        participantsTv.setText("Total de Participantes: " + (students + mentors));
                                                                    } else {
                                                                        studentsTv.setText("Estudantes: 0");
                                                                    }
                                                                }
                                                            });
                                                } else {
                                                    mentorsTv.setText("Mentores: 0");
                                                }
                                            }
                                        });


                            }
                        }
                    }
                });

    }

    public void launchEventParticipantsActivity(View view) {
        Intent intent = new Intent(this, EventParticipantsActivity.class);
        intent.putExtra("eventID", eventId);
        startActivity(intent);
    }

    public void launchCreateGroupsActivity(View view) {
        Intent intent = new Intent(this, CreateGroupsActivity.class);
        intent.putExtra("eventID", eventId);
        intent.putExtra("mentorCode", mentorCode);
        intent.putExtra("userCode", userCode);
        intent.putExtra("eventName", eventName);
        startActivity(intent);
    }

    public void launchListGroupsActivity(View view) {
        Intent intent = new Intent(this, ListGroupsActivity.class);
        intent.putExtra("eventID", eventId);
        startActivity(intent);
    }
}