package pt.ubi.di.agrupameadmin.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

import pt.ubi.di.agrupameadmin.R;
import pt.ubi.di.agrupameadmin.model.Event;

public class GroupsActivity extends AppCompatActivity {

    private LinearLayout groupsLinearLayout;
    private LinearLayout eventCardLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups);
    }


    public void fillEventsInfo() {
        FirebaseFirestore.getInstance().collection("events")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) return;
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            Event event = doc.toObject(Event.class);
                            if (!event.hasOcurred()) {
                                eventCardLinearLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.event_buttons_ll, null);
                                TextView eventNameTv = eventCardLinearLayout.findViewById(R.id.name_ll);
                                TextView eventDateTv = eventCardLinearLayout.findViewById(R.id.date_ll);
                                eventCardLinearLayout.setTag(event.getUuid());
                                eventCardLinearLayout.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        launchGroupsDetailActivity(v);
                                    }
                                });
                                String[] dates = event.getEndDate().toString().split(" ");
                                eventNameTv.setText(event.getName());
                                eventDateTv.setText(dates[2] + " " + dates[1] + " " + dates[5]);
                                groupsLinearLayout.addView(eventCardLinearLayout);
                            }
                        }
                    }
                });
    }

    public void launchGroupsDetailActivity(View view) {
        String eventUid = (String) view.getTag();
        Intent groupDetailIntent = new Intent(this, GroupsDetailActivity.class);
        groupDetailIntent.putExtra("eventID", eventUid);

        startActivity(groupDetailIntent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        groupsLinearLayout = findViewById(R.id.groups_ll);
        groupsLinearLayout.removeAllViews();
        fillEventsInfo();
    }
}