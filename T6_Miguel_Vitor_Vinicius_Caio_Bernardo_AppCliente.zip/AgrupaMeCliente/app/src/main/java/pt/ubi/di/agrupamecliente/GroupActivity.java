package pt.ubi.di.agrupamecliente;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;
import com.xwray.groupie.GroupAdapter;
import com.xwray.groupie.Item;
import com.xwray.groupie.OnItemClickListener;
import com.xwray.groupie.ViewHolder;

public class GroupActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    FirebaseUser currentUser;

    private GroupAdapter adapter;
    private GroupAdapter adapter_2;


    String groupId = "N/A";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        RecyclerView rv_group = findViewById(R.id.recycler_group);
        RecyclerView rv_mentor = findViewById(R.id.recycler_mentor);

        adapter = new GroupAdapter();
        rv_group.setAdapter(adapter);
        rv_group.setLayoutManager(new LinearLayoutManager(this));
        adapter.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(@NonNull Item item, @NonNull View view) {
                Intent intent = new Intent(GroupActivity.this, ProfileActivity.class);
                UserItem userItem = (UserItem) item;
                intent.putExtra("user", userItem.user);
                startActivity(intent);
            }
        });

        adapter_2 = new GroupAdapter();
        rv_mentor.setAdapter(adapter_2);
        rv_mentor.setLayoutManager(new LinearLayoutManager(this));
        adapter_2.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(@NonNull Item item, @NonNull View view) {
                Intent intent = new Intent(GroupActivity.this, ProfileActivity.class);
                UserItem userItem = (UserItem) item;
                intent.putExtra("user", userItem.user);
                startActivity(intent);
            }
        });

        fetchSameGroupMembers();
    }

    private void fetchSameGroupMembers(){
        FirebaseFirestore.getInstance().collection("/students")
                .whereEqualTo("id",currentUser.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            User user = doc.toObject(User.class);
                            groupId = user.getGroupId();
                        }
                        if(!groupId.equals("N/A"))
                        {
                            FirebaseFirestore.getInstance().collection("/students")
                                    .whereEqualTo("groupId",groupId)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                                User user = doc.toObject(User.class);
                                                if(user.getMentor())
                                                    adapter_2.add(new UserItem(user));
                                                else
                                                    adapter.add(new UserItem(user));
                                            }
                                        }
                                    });
                        }
                    }
                });
    }

    private class UserItem extends Item<ViewHolder> {

        private final User user;

        private UserItem(User user){
            this.user = user;
        }

        @Override
        public void bind(@NonNull ViewHolder viewHolder, int position) {
            TextView nameTV =  viewHolder.itemView.findViewById(R.id.name_tv);
            TextView emailTV =  viewHolder.itemView.findViewById(R.id.email_tv);
            TextView schoolTV =  viewHolder.itemView.findViewById(R.id.school_tv);
            ImageView imgPhoto = viewHolder.itemView.findViewById(R.id.imageView2);

            String name = user.getFirstName()+user.getLastName();

            nameTV.setText(name);
            emailTV.setText(user.getEmail());
            schoolTV.setText(user.getSchool());

            if(user.getUrl()!=null)
            {
                Picasso.get()
                        .load(user.getUrl())
                        .into(imgPhoto);
            }

        }
        @Override
        public int getLayout() {
            return R.layout.item_membros;
        }
    }

}