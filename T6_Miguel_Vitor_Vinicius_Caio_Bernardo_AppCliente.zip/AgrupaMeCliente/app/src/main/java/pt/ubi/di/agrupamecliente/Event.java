package pt.ubi.di.agrupamecliente;

import java.util.Date;
import java.util.Random;
import java.util.UUID;

public class Event {

    private String uuid;
    private String name;
    private String description;
    private Date startDate;
    private String time;
    private Date endDate;
    private int maxParticipants;

    private String userCode;
    private String mentorCode;
    private Date createdAt;

    public String genCode() {
        int min = 100;
        int max = 1000;

        int random_int1 = (int) (Math.random() * (max - min + 1) + min);

        Random r = new Random();
        char c1 = (char) (r.nextInt(26) + 'a');
        char c2 = (char) (r.nextInt(26) + 'a');
        char c3 = (char) (r.nextInt(26) + 'a');

        return String.format("%c%c-%d-%c", c1, c2, random_int1, c3);

    }

    public Event() {

    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Event(String name, String description, Date startDate, String time, Date endDate, int maxParticipants) {
        this.uuid = UUID.randomUUID().toString();
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.time = time;
        this.endDate = endDate;
        this.maxParticipants = maxParticipants;
        this.userCode = genCode();
        this.mentorCode = genCode();
        this.createdAt = new Date(System.currentTimeMillis());
    }

    public Event(String uuid, String name, String description, Date startDate, String time, Date endDate, int maxParticipants) {
        this.uuid = UUID.randomUUID().toString();
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.time = time;
        this.endDate = endDate;
        this.maxParticipants = maxParticipants;
        this.userCode = genCode();
        this.mentorCode = genCode();
        this.createdAt = new Date(System.currentTimeMillis());
    }

    public boolean hasOcurred() { // true if its finished/ false if occurred
        Date now = new Date(System.currentTimeMillis());
        return this.endDate.before(now);
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public void setMaxParticipants(int maxParticipants) {
        this.maxParticipants = maxParticipants;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getMentorCode() {
        return mentorCode;
    }

    public void setMentorCode(String mentorCode) {
        this.mentorCode = mentorCode;
    }
}
