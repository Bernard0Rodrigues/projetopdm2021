package pt.ubi.di.agrupamecliente;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class EventActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseUser user;

    private TextView eventName_tv;
    private TextView eventDesc_tv;
    private TextView eventDate_tv;

    String code;
    boolean isMentor;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();

        eventName_tv = (TextView) findViewById(R.id.event_name_label_e);
        eventDesc_tv = (TextView) findViewById(R.id.event_desc_label_e);
        eventDate_tv = (TextView) findViewById(R.id.event_date_label_e);



        FirebaseFirestore.getInstance().collection("/students")
                .whereEqualTo("id",user.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            User user = doc.toObject(User.class);
                            code = user.getCode();
                            isMentor = user.getMentor();
                        }
                        if(isMentor)
                        {
                            FirebaseFirestore.getInstance().collection("/events")
                                    .whereEqualTo("mentorCode",code)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                                Event event = doc.toObject(Event.class);
                                                eventName_tv.setText(event.getName());
                                                eventDesc_tv.setText(event.getDescription());
                                                String[] dates = event.getEndDate().toString().split(" ");
                                                String toSet = dates[2] + " " + dates[1] + " " + dates[5];
                                                eventDate_tv.setText(toSet);
                                            }
                                        }
                                    });
                        }
                        else
                        {
                            FirebaseFirestore.getInstance().collection("/events")
                                    .whereEqualTo("userCode",code)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                                Event event = doc.toObject(Event.class);
                                                eventName_tv.setText(event.getName());
                                                eventDesc_tv.setText(event.getDescription());
                                                String[] dates = event.getEndDate().toString().split(" ");
                                                String toSet = dates[2] + " " + dates[1] + " " + dates[5];
                                                eventDate_tv.setText(toSet);
                                            }
                                        }
                                    });
                        }
                    }
                });

    }
}


