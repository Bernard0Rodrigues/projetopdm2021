package pt.ubi.di.agrupamecliente;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class ProfileActivity extends AppCompatActivity {


    private ImageView imgAvatar;
    private TextView primeiroNome, ultimoNome, idade, genero, email, area, escola, localidade ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        imgAvatar = findViewById(R.id.imgAvatar);
        primeiroNome = findViewById(R.id.txtViewPrimeiroNome);
        ultimoNome = findViewById(R.id.txtViewUltimoNome);
        idade = findViewById(R.id.txtViewIdade);
        genero = findViewById(R.id.txtGenero);
        email = findViewById(R.id.txtemail);
        area = findViewById(R.id.field_study_label_i2);
        escola = findViewById(R.id.school_label_i2);
        localidade = findViewById(R.id.residence_label_i2);

        User user = getIntent().getExtras().getParcelable( "user");
        primeiroNome.setText(user.getFirstName());
        ultimoNome.setText(user.getLastName());
        email.setText(user.getEmail());
        idade.setText(String.valueOf(user.getAge()));
        genero.setText(user.getGender());

        area.setText(user.getFieldStudy());
        escola.setText(user.getSchool());
        localidade.setText(user.getResidence());

        if(user.getUrl()!=null)
        {
            Picasso.get()
                    .load(user.getUrl())
                    .into(imgAvatar);
        }

    }
}