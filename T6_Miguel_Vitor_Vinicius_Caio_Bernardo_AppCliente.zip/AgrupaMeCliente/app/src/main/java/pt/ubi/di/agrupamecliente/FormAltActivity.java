package pt.ubi.di.agrupamecliente;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class FormAltActivity extends AppCompatActivity{
    private FirebaseAuth mAuth;
    FirebaseUser currentUser;
    private EditText loginUuid_et;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_alt);

        loginUuid_et = (EditText) findViewById(R.id.login_uuid_et);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

    }

    public void confirmID(View view) {
        FirebaseFirestore.getInstance().collection("/students")
                .whereEqualTo("id", loginUuid_et.getText().toString())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            DocumentReference docRef = FirebaseFirestore.getInstance().collection("/students").document(doc.getId());
                            docRef.update("id",currentUser.getUid());
                            User user = doc.toObject(User.class);

                            SharedPreferences sharedPrefIsActive = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                            SharedPreferences.Editor editorIsActive = sharedPrefIsActive.edit();
                            SharedPreferences sharedPrefID = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                            SharedPreferences.Editor editorID = sharedPrefID.edit();
                            SharedPreferences sharedPrefCode = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                            SharedPreferences.Editor editorCode = sharedPrefCode.edit();
                            SharedPreferences sharedPrefIsMentor = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                            SharedPreferences.Editor editorIsMentor = sharedPrefIsMentor.edit();
                            editorIsActive.putBoolean("isActive", true);
                            editorIsActive.apply();
                            editorID.putString("currentUserID", user.getID());
                            editorID.apply();
                            editorCode.putString("Code", user.getCode());
                            editorCode.apply();
                            editorIsMentor.putBoolean("isMentor", user.getMentor());
                            editorIsMentor.apply();
                            Intent intent = new Intent(FormAltActivity.this, MenuActivity.class);
                            startActivity(intent);
                        }
                    }
                });
    }
}
