package pt.ubi.di.agrupamecliente;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class InfoActivity extends AppCompatActivity
{
    private FirebaseAuth mAuth;
    private FirebaseUser user;

    private TextView userID_tv;
    private TextView emailID_tv;
    private TextView firstName_tv;
    private TextView lastName_tv;
    private TextView gender_label_tv;
    private TextView age_tv;
    private TextView school_tv;
    private TextView fieldStudy_tv;
    private TextView residence_tv;

    private CircleImageView imgViewAvatar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitvity_info);

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();

        userID_tv = (TextView) findViewById(R.id.user_ID_label_i);
        emailID_tv = (TextView) findViewById(R.id.login_email_label_i);
        firstName_tv = (TextView) findViewById(R.id.first_name_label_i);
        lastName_tv = (TextView) findViewById(R.id.last_name_label_i);
        gender_label_tv = (TextView) findViewById(R.id.gender_label_i);
        age_tv = (TextView) findViewById(R.id.age_label_i);
        school_tv = (TextView) findViewById(R.id.school_label_i);
        fieldStudy_tv = (TextView) findViewById(R.id.field_study_label_i);
        residence_tv = (TextView) findViewById(R.id.residence_label_i);
        imgViewAvatar = findViewById(R.id.CircleImgViewAvatar);

        FirebaseFirestore.getInstance().collection("/students")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if( error != null)
                            return;
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for(DocumentSnapshot doc: docs)
                        {
                            User currentUser = doc.toObject(User.class);
                            if(currentUser.getID().equals(user.getUid()))
                            {
                                if(currentUser.getUrl() != null) {
                                    Picasso.get()    //Esta biblioteca vai carregar a imagem no imgView
                                            .load(currentUser.getUrl())
                                            .into(imgViewAvatar);
                                }
                                userID_tv.setText(currentUser.getID());
                                emailID_tv.setText(currentUser.getEmail());
                                firstName_tv.setText(currentUser.getFirstName());
                                lastName_tv.setText(currentUser.getLastName());
                                age_tv.setText(String.valueOf(currentUser.getAge()));
                                gender_label_tv.setText(currentUser.getGender());
                                school_tv.setText(currentUser.getSchool());
                                fieldStudy_tv.setText(currentUser.getFieldStudy());
                                residence_tv.setText(currentUser.getResidence());
                            }
                        }
                    }
                });
    }
}
