package pt.ubi.di.agrupamecliente;

import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable
{
   private String uuid;
   private String email;
   private String firstName;
   private String lastName;
   private String school;
   private String fieldStudy;
   private String residence;
   private String gender;
   private String accessCode;
   private boolean isMentor;
   private int age;
   private String url;
   private String groupId;



    public User(String uuid, String email, String firstName, String lastName, String school, String fieldStudy, String residence, String gender, int age, boolean isMentor, String accessCode, String url)
    {
        this.uuid = uuid;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.school = school;
        this.fieldStudy = fieldStudy;
        this.residence = residence;
        this.gender = gender;
        this.age = age;
        this.isMentor = isMentor;
        this.accessCode = accessCode;
        this.url = url;
        this.groupId = "N/A";
    }
    public User() {
    }

    protected User(Parcel in) {
        uuid = in.readString();
        email = in.readString();
        firstName = in.readString();
        lastName = in.readString();
        school = in.readString();
        fieldStudy = in.readString();
        residence = in.readString();
        gender = in.readString();
        accessCode = in.readString();
        isMentor = in.readByte() != 0;
        age = in.readInt();
        url = in.readString();
        groupId = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getID() {
        return uuid;
    }
    public void setID(String uuid) {
        this.uuid = uuid;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSchool() {
        return school;
    }
    public void setSchool(String school) {
        this.school = school;
    }

    public String getFieldStudy() {
        return fieldStudy;
    }
    public void setFieldStudy(String fieldStudy) {
        this.fieldStudy = fieldStudy;
    }

    public String getResidence() {
        return residence;
    }
    public void setResidence(String residence) {
        this.residence = residence;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public boolean getMentor() {
        return isMentor;
    }
    public void setMentor(boolean isMentor) {
        this.isMentor = isMentor;
    }

    public String getCode() {
        return accessCode;
    }
    public void setCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(uuid);
        dest.writeString(email);
        dest.writeString(firstName);
        dest.writeString(lastName);
        dest.writeString(school);
        dest.writeString(fieldStudy);
        dest.writeString(residence);
        dest.writeString(gender);
        dest.writeString(accessCode);
        dest.writeByte((byte) (isMentor ? 1 : 0));
        dest.writeInt(age);
        dest.writeString(url);
        dest.writeString(groupId);
    }
}
