package pt.ubi.di.agrupamecliente;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
    public void goToInfo(View view)
    {
        Intent intent = new Intent(MenuActivity.this, InfoActivity.class);
        startActivity(intent);
    }
    public void goToGroup(View view)
    {
        Intent intent = new Intent(MenuActivity.this, GroupActivity.class);
        startActivity(intent);
    }
    public void goToEvent(View view)
    {
        Intent intent = new Intent(MenuActivity.this, EventActivity.class);
        startActivity(intent);
    }
    @Override
    public void onBackPressed(){
    }

}
