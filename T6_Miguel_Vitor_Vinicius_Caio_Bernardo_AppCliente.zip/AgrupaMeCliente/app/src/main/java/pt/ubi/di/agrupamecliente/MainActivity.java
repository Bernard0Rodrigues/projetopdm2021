package pt.ubi.di.agrupamecliente;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class MainActivity extends AppCompatActivity
{
    private FirebaseAuth mAuth;

    private EditText code_et;
    private TextView code_tv;

    boolean noResult = true;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();

        SharedPreferences sharedPrefIsActive = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences sharedPrefActiveCode = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences sharedPrefIsMentor = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        boolean isActive=sharedPrefIsActive.getBoolean("isActive",false);
        String code=sharedPrefActiveCode.getString("Code","ERROR");
        boolean isMentor=sharedPrefIsMentor.getBoolean("isMentor",false);

        if(isActive) // if previous Event/Session was started
        {// need to make sure if it happened or not
            if(isMentor) // we need to search this way to know what event it is; so we either choose by userCode or mentorCode
            {// if code is mentor
                FirebaseFirestore.getInstance().collection("events")
                        .whereEqualTo("mentorCode", code)
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Event eventFound = document.toObject(Event.class); // we check if date as passed or not
                                        if(eventFound.hasOcurred())
                                        {// if date has passed we reset
                                            resetState();
                                        }
                                    }
                                    boolean isActive=sharedPrefIsActive.getBoolean("isActive",false);
                                    if(isActive) // check if it is still active (might have changed if its over the time limit
                                    {
                                        // if we reach here it means the event is still going (it has not passed final date)
                                        Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                                        startActivity(intent);
                                    }
                                } else {
                                }
                            }
                        });
            }
            else
            {// if it is user
                FirebaseFirestore.getInstance().collection("events")
                        .whereEqualTo("userCode", code)
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Event eventFound = document.toObject(Event.class); // we check if date as passed or not
                                        if(eventFound.hasOcurred())
                                        {// if date has passed we reset
                                            resetState();
                                        }
                                    }
                                    boolean isActive=sharedPrefIsActive.getBoolean("isActive",false);
                                    if(isActive) // check if it is still active (might have changed if its over the time limit
                                    {
                                        // if we reach here it means the event is still going (it has not passed final date)
                                        Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                                        startActivity(intent);
                                    }
                                } else {
                                }
                            }
                        });
            }
        }
        else //isActive==false
        {
            setContentView(R.layout.activity_main);
            code_et = (EditText) findViewById(R.id.code_et);
            code_tv = (TextView) findViewById(R.id.code_tv);
        }
    }
    public void confirmCode(View view)
    {// fetch events and compare to see if we can find code (right) in it
        FirebaseFirestore.getInstance().collection("/events")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if( error != null)
                            return;
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for(DocumentSnapshot doc: docs)
                        {
                            Event currentEvent = doc.toObject(Event.class);
                            if(compareCode(code_et.getText().toString(),currentEvent.getUserCode()) && !currentEvent.hasOcurred())
                            {
                                noResult = false;
                                Intent intent = new Intent(MainActivity.this, FormActivity.class);
                                intent.putExtra("code",currentEvent.getUserCode());
                                intent.putExtra("isMentor",false);
                                startActivity(intent);
                            }
                            else if(compareCode(code_et.getText().toString(),currentEvent.getMentorCode()) && !currentEvent.hasOcurred())
                            {
                                noResult = false;
                                Intent intent = new Intent(MainActivity.this, FormActivity.class);
                                intent.putExtra("code",currentEvent.getMentorCode());
                                intent.putExtra("isMentor",true);
                                startActivity(intent);
                            }
                        }
                        if(noResult)
                            code_tv.setText(R.string.code_wrong_tv_hint);
                    }
                });
    }
    public void confirmAlt(View view) {
        Intent intent = new Intent(MainActivity.this, FormAltActivity.class);
        startActivity(intent);
    }
    private boolean compareCode(String codeApp,String codeEvent)
    {
        return codeApp.equals(codeEvent); // true if code is right
    }
    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        signIn(currentUser);
    }

    public void signIn(FirebaseUser user) {
        if (user == null) {
            mAuth.signInAnonymously().addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                    } else {
                    }
                }
            });
        }
    }
    public void resetState()
    {
        SharedPreferences sharedPrefIsActive = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences sharedPrefID = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences sharedPrefCode = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences sharedPrefIsMentor = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);

        SharedPreferences.Editor editorIsActive = sharedPrefIsActive.edit();
        SharedPreferences.Editor editorIsMentor = sharedPrefIsMentor.edit();
        SharedPreferences.Editor editorID = sharedPrefID.edit();
        SharedPreferences.Editor editorCode = sharedPrefCode.edit();

        editorIsActive.putBoolean("isActive", false);
        editorIsMentor.putBoolean("isMentor", false);
        editorID.putString("currentUserID", "");
        editorCode.putString("Code", "");

        editorIsActive.apply();
        editorIsMentor.apply();
        editorID.apply();
        editorCode.apply();

        setContentView(R.layout.activity_main);

        code_et = (EditText) findViewById(R.id.code_et);
        code_tv = (TextView) findViewById(R.id.code_tv);

        mAuth.signOut();
    }
}