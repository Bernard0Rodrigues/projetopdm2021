package pt.ubi.di.agrupamecliente;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class FormActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;

    private EditText emailID_et;
    private EditText firstName_et;
    private EditText lastName_et;
    private EditText fieldStudy_et;
    private EditText residence_et;
    private EditText age_et;
    private Spinner school_sp;
    private Spinner gender_sp;

    private Button btnAvatar;
    private Uri avatarURL;
    private ImageView photo;

    private String[] genders = {"Masculino", "Feminino"};
    private ArrayList<String> schools = new ArrayList<String>();
    private String userGender;
    private String userSchool;
    private String code;
    private boolean isMentor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        // receiving Intent
        Intent intent = getIntent();
        code = intent.getStringExtra("code");
        isMentor = intent.getBooleanExtra("isMentor", false);

        mAuth = FirebaseAuth.getInstance();

        emailID_et = (EditText) findViewById(R.id.login_email_et);
        firstName_et = (EditText) findViewById(R.id.first_name_et);
        lastName_et = (EditText) findViewById(R.id.last_name_et);
        fieldStudy_et = (EditText) findViewById(R.id.field_study_et);
        residence_et = (EditText) findViewById(R.id.residence_et);
        age_et = (EditText) findViewById(R.id.age_et);
        school_sp = (Spinner) findViewById(R.id.school_et);
        gender_sp = (Spinner) findViewById(R.id.gender_sp);
        btnAvatar = findViewById(R.id.btn_uploadAvatar);
        photo = findViewById(R.id.imgViewFoto);

        btnAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAvatar();
            }
        });
        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAvatar();
            }
        });
        // setting up spinner for choosing school
        FirebaseFirestore.getInstance().collection("/schools")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null)
                            return;
                        List<DocumentSnapshot> docs = value.getDocuments();
                        for (DocumentSnapshot doc : docs) {
                            School school = doc.toObject(School.class);
                            schools.add(school.getName());
                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(FormActivity.this, android.R.layout.simple_spinner_item, schools);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        school_sp.setAdapter(adapter);
                        school_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                userSchool = (String) parent.getItemAtPosition(position);
                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                            }
                        });
                    }
                });
        // --------------------------------------
        // setting up spinner for choosing gender
        ArrayAdapter<String> adapter_g = new ArrayAdapter<String>(FormActivity.this, android.R.layout.simple_spinner_item, genders);
        adapter_g.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gender_sp.setAdapter(adapter_g);
        gender_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                userGender = (String) parent.getItemAtPosition(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        // --------------------------------------
    }
    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        signIn(currentUser);
    }
    public void signIn(FirebaseUser user) {
        if (user == null) {
            mAuth.signInAnonymously().addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                    } else {
                    }
                }
            });
        }
    }
    public void confirmForm(View view) {
        String filename = UUID.randomUUID().toString();
        final StorageReference ref = FirebaseStorage.getInstance().getReference("images/" + filename);
        if(avatarURL == null){
            addUser(mAuth.getUid(), emailID_et.getText().toString(), firstName_et.getText().toString(), lastName_et.getText().toString(), userSchool, fieldStudy_et.getText().toString(), residence_et.getText().toString(), userGender, age_et.getText().toString(), isMentor, code, null);
        }else {
            ref.putFile(avatarURL)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    addUser(mAuth.getUid(), emailID_et.getText().toString(), firstName_et.getText().toString(), lastName_et.getText().toString(), userSchool, fieldStudy_et.getText().toString(), residence_et.getText().toString(), userGender, age_et.getText().toString(), isMentor, code, uri.toString());
                                }
                            });
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                        }
                    });
        }
    }

    public void addUser(String uid, String email, String firstName, String lastName, String school, String study, String residence, String gender, String Age, Boolean mentor, String code, String Uri ){
        User newUser = new User(uid, email, firstName, lastName, school, study, residence, gender, Integer.parseInt(Age.toString()), mentor, code, Uri);
        FirebaseFirestore.getInstance().collection("/students")
                .add(newUser)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        SharedPreferences sharedPrefIsActive = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                        SharedPreferences.Editor editorIsActive = sharedPrefIsActive.edit();
                        SharedPreferences sharedPrefID = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                        SharedPreferences.Editor editorID = sharedPrefID.edit();
                        SharedPreferences sharedPrefCode = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                        SharedPreferences.Editor editorCode = sharedPrefCode.edit();
                        SharedPreferences sharedPrefIsMentor = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                        SharedPreferences.Editor editorIsMentor = sharedPrefIsMentor.edit();
                        editorIsActive.putBoolean("isActive", true);
                        editorIsActive.apply();
                        editorID.putString("currentUserID", newUser.getID());
                        editorID.apply();
                        editorCode.putString("Code", newUser.getCode());
                        editorCode.apply();
                        editorIsMentor.putBoolean("isMentor", newUser.getMentor());
                        editorIsMentor.apply();
                        Intent intent = new Intent(FormActivity.this, MenuActivity.class);
                        startActivity(intent);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                    }
                });

    }
    private void selectAvatar() {
        Intent it = new Intent(Intent.ACTION_PICK);
        it.setType("image/*");
        startActivityForResult(it, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0  && resultCode == RESULT_OK && data != null ) {
            avatarURL = data.getData();

            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), avatarURL);
                photo.setImageDrawable(new BitmapDrawable(bitmap));
                btnAvatar.setAlpha(0);
                btnAvatar.setVisibility(View.GONE);

            } catch (IOException e) {

            }
        }else{
            Toast.makeText(this,"Não selecionou nenhuma imagem!", Toast.LENGTH_SHORT).show();
        }


    }
}
